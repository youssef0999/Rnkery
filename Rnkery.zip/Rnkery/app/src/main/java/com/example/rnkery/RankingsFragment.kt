package com.example.rnkery

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class RankingsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_rankings, container, false)
    }
    /*
    //SEGMENTED CONTROL STATES//
    segButton.setOnClickedButtonPosition
    {
        fun onClickedButtonPosition(position: Int) {

            if (position == 0) {/*do things here*/
            } else if (position == 1) {/*do other things here*/
            }

        }
        //SEGMENTED CONTROL STATES//
     */
}
